<?php
include 'koneksi.php';

function uploadToDatabase($data) {
    global $conn;

    $suhu = $data['suhu'];
    $kelembaban_udara = $data['kelembaban_udara'];
    $kelembaban_tanah = $data['kelembaban_tanah'];
    $tanggal = $data['tanggal'];
    $waktu = $data['waktu'];

    $sql = "INSERT INTO project (suhu, kelembaban_udara, kelembaban_tanah, tanggal, waktu)
            VALUES ('$suhu', '$kelembaban_udara', '$kelembaban_tanah', '$tanggal', '$waktu')";

    if ($conn->query($sql) === TRUE) {
        return [
            "status" => "success",
            "message" => "Data berhasil diupload",
            "data" => [
                "suhu" => $suhu,
                "kelembaban_udara" => $kelembaban_udara,
                "kelembaban_tanah" => $kelembaban_tanah,
            ]
        ];
    } else {
        return [
            "status" => "error",
            "message" => "Gagal mengupload data: " . $conn->error
        ];
    }
}

$conn->close();
?>
