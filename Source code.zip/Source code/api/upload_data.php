<?php
include 'koneksi.php';

// Cek apakah relay_control diatur
if (isset($_POST['relay_control'])) {
    $relayControl = $_POST['relay_control']; // 'ON' atau 'OFF'

    // Kirim respons ke Flutter
    $response = [
        "status" => "success",
        "message" => "Relay diatur menjadi $relayControl",
        "relay_status" => $relayControl
    ];

    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Cek apakah data sensor dikirim
if (isset($_POST['suhu']) && isset($_POST['kelembaban_udara']) && isset($_POST['kelembaban_tanah']) && isset($_POST['tanggal']) && isset($_POST['waktu'])) {
    $suhu = $_POST['suhu'];
    $kelembaban_udara = $_POST['kelembaban_udara'];
    $kelembaban_tanah = $_POST['kelembaban_tanah'];
    $tanggal = $_POST['tanggal'];
    $waktu = $_POST['waktu'];

    // Logika untuk menentukan status relay
    $status_relay = ($kelembaban_tanah < 30) ? 'ON' : 'OFF';

    $sql = "INSERT INTO project (suhu, kelembaban_udara, kelembaban_tanah, tanggal, waktu, relay_status)
            VALUES ('$suhu', '$kelembaban_udara', '$kelembaban_tanah', '$tanggal', '$waktu', '$status_relay')";

    if ($conn->query($sql) === TRUE) {
        $response = [
            "status" => "success",
            "message" => "Data berhasil diupload",
            "data" => [
                "suhu" => $suhu,
                "kelembaban_udara" => $kelembaban_udara,
                "kelembaban_tanah" => $kelembaban_tanah,
                "relay_status" => $status_relay
            ]
        ];
    } else {
        $response = [
            "status" => "error",
            "message" => "Gagal mengupload data: " . $conn->error
        ];
    }
} else {
    $response = [
        "status" => "error",
        "message" => "Data tidak lengkap"
    ];
}

header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
