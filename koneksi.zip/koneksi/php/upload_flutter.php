<?php
file_put_contents("debug.log", print_r($_POST, true), FILE_APPEND);

$suhu = $_POST['suhu'] ?? null;
$kelembaban_udara = $_POST['kelembaban_udara'] ?? null;
$kelembaban_tanah = $_POST['kelembaban_tanah'] ?? null;

if ($suhu === null || $kelembaban_udara === null || $kelembaban_tanah === null) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Data tidak lengkap. Harap kirim suhu, kelembaban udara, dan kelembaban tanah.'
    ]);
    exit;
}

header('Content-Type: application/json');
echo json_encode([
    'status' => 'success',
    'data' => [
        'suhu' => $suhu,
        'kelembaban_udara' => $kelembaban_udara,
        'kelembaban_tanah' => $kelembaban_tanah,
    ],
    'message' => 'Data berhasil diterima'
]);
?>
