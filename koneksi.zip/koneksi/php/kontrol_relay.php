<?php
require_once 'phpserial.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : null;
    $mode = isset($_POST['mode']) ? $_POST['mode'] : null;

    if ($action && ($mode === 'manual' || $mode === 'auto')) {
        try {
            $serial = new PhpSerial();

            $serial->deviceSet("COM4");

            $serial->confBaudRate(115200);
            $serial->confParity("none");
            $serial->confCharacterLength(8);
            $serial->confStopBits(1);
            $serial->confFlowControl("none");

            $serial->deviceOpen();

            $data = json_encode([
                "mode" => $mode,
                "action" => $action
            ]);

            $serial->sendMessage($data);

            $serial->deviceClose();

            echo json_encode(["status" => "success", "message" => ucfirst($mode) . " mode updated: $action"]);
        } catch (Exception $e) {
            echo json_encode(["status" => "error", "message" => "Failed to send data to ESP32: " . $e->getMessage()]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid request"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid method"]);
}
?>
