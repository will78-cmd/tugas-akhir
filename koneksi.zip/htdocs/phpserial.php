<?php
/**
 * PhpSerial Library
 * A PHP library to interact with the serial port.
 * 
 * @author Rémy Sanchez
 * @link https://github.com/Xowap/PHP-Serial
 */

class PhpSerial
{
    var $_device = null;
    var $_dHandle = null;
    var $_dState = null;
    var $_buffer = null;
    var $_os = "linux";

    function __construct()
    {
        $this->_dState = false;
        $this->_buffer = "";
    }

    function deviceSet($device)
    {
        $this->_device = $device;
    }

    function confBaudRate($rate)
    {
        $this->_exec(
            sprintf("stty -F %s %d", escapeshellarg($this->_device), $rate),
            "Unable to set baud rate."
        );
    }

    function confParity($parity)
    {
        $parity = strtolower($parity);
        if (!in_array($parity, array("none", "odd", "even"))) {
            throw new Exception("Invalid parity type.");
        }
        $this->_exec(
            sprintf("stty -F %s -parenb", escapeshellarg($this->_device)),
            "Unable to set parity."
        );
    }

    function confCharacterLength($length)
    {
        if (!in_array($length, array(5, 6, 7, 8))) {
            throw new Exception("Invalid character length.");
        }
        $this->_exec(
            sprintf("stty -F %s cs%d", escapeshellarg($this->_device), $length),
            "Unable to set character length."
        );
    }

    function confStopBits($length)
    {
        if (!in_array($length, array(1, 2))) {
            throw new Exception("Invalid stop bits.");
        }
        $this->_exec(
            sprintf("stty -F %s %d", escapeshellarg($this->_device), $length),
            "Unable to set stop bits."
        );
    }

    function confFlowControl($mode)
    {
        $mode = strtolower($mode);
        if ($mode === "none") {
            $this->_exec(
                sprintf("stty -F %s -crtscts", escapeshellarg($this->_device)),
                "Unable to set flow control."
            );
        } else {
            throw new Exception("Invalid flow control mode.");
        }
    }

    function deviceOpen()
    {
        $this->_dHandle = fopen($this->_device, "c+");
        if ($this->_dHandle === false) {
            throw new Exception("Unable to open the device.");
        }
        $this->_dState = true;
    }

    function deviceClose()
    {
        if ($this->_dState === true) {
            fclose($this->_dHandle);
            $this->_dState = false;
        }
    }

    function sendMessage($message)
    {
        if ($this->_dState !== true) {
            throw new Exception("Device must be opened to send data.");
        }

        fwrite($this->_dHandle, $message);
    }

    private function _exec($cmd, $errorMsg)
    {
        $output = array();
        $returnVar = null;
        exec($cmd, $output, $returnVar);
        if ($returnVar !== 0) {
            throw new Exception($errorMsg);
        }
    }
}
?>
