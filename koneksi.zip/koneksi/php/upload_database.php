<?php 
include 'koneksi.php';

file_put_contents("debug.log", print_r($_POST, true), FILE_APPEND);

function uploadToDatabase($data) {
    global $conn;

    $suhu = isset($data['suhu']) ? $conn->real_escape_string($data['suhu']) : null;
    $kelembaban_udara = isset($data['kelembaban_udara']) ? $conn->real_escape_string($data['kelembaban_udara']) : null;
    $kelembaban_tanah = isset($data['kelembaban_tanah']) ? $conn->real_escape_string($data['kelembaban_tanah']) : null;
    $tanggal = isset($data['tanggal']) ? $conn->real_escape_string($data['tanggal']) : null;
    $waktu = isset($data['waktu']) ? $conn->real_escape_string($data['waktu']) : null;

    if ($suhu && $kelembaban_udara && $kelembaban_tanah && $tanggal && $waktu) {
        $sql = "INSERT INTO project (suhu, kelembaban_udara, kelembaban_tanah, tanggal, waktu) 
                VALUES ('$suhu', '$kelembaban_udara', '$kelembaban_tanah', '$tanggal', '$waktu')";
        if ($conn->query($sql) === TRUE) {
            return "Data berhasil disimpan";
        } else {
            return "Error: " . $sql . " - " . $conn->error;
        }
    } else {
        return "Error: Data tidak lengkap";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = uploadToDatabase($_POST);
    echo $response;
} else {
    echo "Error: Hanya menerima metode POST";
}

$conn->close();
?>
