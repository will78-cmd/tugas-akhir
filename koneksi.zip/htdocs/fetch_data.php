<?php
include 'koneksi.php';
try {
    $stmt = $pdo->prepare("SELECT no, suhu, `kelembaban udara`, `kelembaban tanah`, tanggal, waktu FROM project ORDER BY no ASC");
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($data);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Query failed: ' . $e->getMessage()]);
}
?>



