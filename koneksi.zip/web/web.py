import streamlit as st  # type: ignore
import requests  # type: ignore
import mysql.connector  # type: ignore
import pandas as pd  # type: ignore
import plotly.express as px  # type: ignore

PHP_API_URL = "http://localhost/upload_flutter.php"

DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'project'
}

def upload_flutter():
    try:
        response = requests.get(PHP_API_URL)
        data = response.json()
        return {
            "suhu": float(data['suhu']),
            "kelembaban_udara": float(data['kelembaban_udara']),
            "kelembaban_tanah": float(data['kelembaban_tanah'])
        }
    except Exception as e:
        st.error(f"Error mengambil data sensor: {e}")
        return {"suhu": 0, "kelembaban_udara": 0, "kelembaban_tanah": 0}

def get_database_data():
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        query = "SELECT * FROM project"
        df = pd.read_sql(query, connection)
        connection.close()
        return df
    except Exception as e:
        st.error(f"Error koneksi database: {e}")
        return pd.DataFrame()

def control_relay(action, mode):
    try:
        requests.post(
            "http://localhost/kontrol_relay.php",
            data={'action': action, 'mode': mode}
        )
    except Exception as e:
        st.error(f"Error mengontrol relay: {e}")

st.set_page_config(page_title="Kontrol dan Monitoring", layout="wide")
st.title("Kontrol Relay dan Monitoring Sensor")

sensor_data = upload_flutter()
df = get_database_data()

st.write("### Data Sensor Real Time")
col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("#### 🌡️ Suhu")
    st.info(f"{sensor_data['suhu']} °C")

with col2:
    st.markdown("#### 💧 Kelembaban Udara")
    st.info(f"{sensor_data['kelembaban_udara']}%")

with col3:
    st.markdown("#### 🌱 Kelembaban Tanah")
    st.info(f"{sensor_data['kelembaban_tanah']}%")

if not df.empty:
    col4, col5, col6 = st.columns(3)

    with col4:
        fig_suhu = px.line(df, x=df.index, y='suhu')
        st.plotly_chart(fig_suhu, use_container_width=True)

    with col5:
        fig_kelembaban_udara = px.line(df, x=df.index, y='kelembaban_udara')
        st.plotly_chart(fig_kelembaban_udara, use_container_width=True)

    with col6:
        fig_kelembaban_tanah = px.line(df, x=df.index, y='kelembaban_tanah')
        st.plotly_chart(fig_kelembaban_tanah, use_container_width=True)
else:
    st.write("Tidak ada data di database untuk ditampilkan sebagai grafik.")

st.write("### Kontrol Relay")

col7, col8 = st.columns(2)

with col7:
    st.subheader("Kontrol Manual")
    
    relay1 = st.toggle("Relay 1")
    relay2 = st.toggle("Relay 2")
    relay3 = st.toggle("Relay 3")
    relay4 = st.toggle("Relay 4")

    if relay1:
        control_relay("ON", "manual")
    else:
        control_relay("OFF", "manual")

    if relay2:
        control_relay("ON", "manual")
    else:
        control_relay("OFF", "manual")

    if relay3:
        control_relay("ON", "manual")
    else:
        control_relay("OFF", "manual")

    if relay4:
        control_relay("ON", "manual")
    else:
        control_relay("OFF", "manual")

with col8:
    st.subheader("Kontrol Otomatis")
    auto_mode = st.toggle("Aktifkan Mode Otomatis")
    if auto_mode:
        control_relay("ON", "auto")
    else:
        control_relay("OFF", "auto")

st.write("### History")
if not df.empty:
    st.dataframe(df)
else:
    st.write("Tidak ada data untuk ditampilkan.")
