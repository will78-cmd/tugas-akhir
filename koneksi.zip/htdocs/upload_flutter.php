<?php
$suhu = $_POST['suhu'] ?? '';
$kelembaban_udara = $_POST['kelembaban_udara'] ?? '';
$kelembaban_tanah = $_POST['kelembaban_tanah'] ?? '';

if (empty($suhu) || empty($kelembaban_udara) || empty($kelembaban_tanah)) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Data tidak lengkap',
    ]);
    exit;
}

header('Content-Type: application/json');
echo json_encode([
    'status' => 'success',
    'message' => 'Data diterima',
    'data' => [
        'suhu' => $suhu,
        'kelembaban_udara' => $kelembaban_udara,
        'kelembaban_tanah' => $kelembaban_tanah,
    ]
]);
?>
